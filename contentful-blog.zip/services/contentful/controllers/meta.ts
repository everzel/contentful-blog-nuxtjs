export interface IMeta {
  title: string;
  description: string;
  image_url: string;
  indexable: boolean;
}