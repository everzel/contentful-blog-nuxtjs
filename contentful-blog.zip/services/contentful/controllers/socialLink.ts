export interface ISocialLink {
  type: 'Instagram' | 'Twitter (X)';
  url: string;
}