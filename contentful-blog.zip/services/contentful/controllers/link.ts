export interface ILink {
  name: string;
  url: string;
}