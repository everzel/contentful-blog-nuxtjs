<script setup lang="ts">
</script>

<template>
  <NuxtLoadingIndicator
    color="#4f46e5"
    :height="2"
    :opacity="0.6"
  />

  <NuxtPage/>
</template>